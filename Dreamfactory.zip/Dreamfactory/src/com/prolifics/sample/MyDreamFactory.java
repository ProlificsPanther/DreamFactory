package com.prolifics.sample;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.prolifics.jni.Application;
import com.prolifics.jni.ApplicationInterface;
import com.prolifics.jni.CFunctionsInterface;
import org.json.JSONObject;

public class MyDreamFactory {
	
ApplicationInterface ai = Application.getInstance();
CFunctionsInterface cf = ai.getCFunctions();

//HTTP GET request
		public void getResource(String email, String password, String url) throws Exception {
			String token = getSessionToken(email, password);
			
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			con.setRequestProperty("accept", "application/json");
			con.setRequestProperty("X-DreamFactory-Session-Token", token);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		
		    String str = response.toString();
		    con.disconnect();
		    cf.sm_n_ww_write("jsonreceiver",str ,0);
		}

	// HTTP POST request
		public String getSessionToken(String email, String password) throws Exception {
			
			String url = "http://localhost/api/v2/system/admin/session";
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			//add reuqest header
			con.setRequestMethod("POST");
			
			String urlParameters = "email="+email+"&password="+password;
			
			// Send post request
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			
			String json_response = response.toString();
			
			//print result 
			JSONObject jsonObj = new JSONObject(json_response);
			con.disconnect();
			String token = jsonObj.getString("session_token");
			return token;
		}

}